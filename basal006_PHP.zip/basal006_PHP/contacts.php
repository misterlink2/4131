﻿<?php
  session_start();
//  echo "session " . $_SESSION["value"] . ".<br>";
  if($_SESSION["value"] != 1){
   echo '<script>window.location = "http://www-users.cselabs.umn.edu/~basal006/login.php" </script>';
  }
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
  <body>
      <nav class="navbar navbar-default">
          <div class="container-fluid">
              <ul class="nav navbar-nav">
                  <li><a href=#><b>Contacts</b></a></li>
                  <li><a href=#><b><?php echo $_SESSION["name"] ?></b></a></li>
                  <li><a href="http://www-users.cselabs.umn.edu/~basal006/login.php"><b>log out</b></a></li>
              </ul>
          </div>
      </nav>
      <br><br>


<form action="#" method="post">
<select name="sort">
  <option value="contact_name">Name</option>
  <option value="contact_email">Email</option>
  <option value="contact_address">Address</option>
  <option value="contact_phone">Phone</option>
  <option value="contact_favoriteplace">Place</option>
  <option value="contact_favoriteplaceurl">URL</option>
</select>
<input type ="text" name = "filter"><br>
<input type="submit" name="submit" value="filter" />
</form>
<?php
if(isset($_POST['submit'])){
$selected_val = $_POST['sort'];  // Storing Selected Value In Variable
$typed_val = $_POST['filter'];  // Storing Selected Value In Variable
//echo "You have selected :" .$selected_val;  // Displaying Selected Value
//echo "\n";
//echo "typed: " .$typed_val;
//echo "<br>";
  //echo "session " . $_SESSION["value"] . ".<br>";
error_reporting(E_ALL);
ini_set( 'display_errors','1');
include_once 'database.php';
$con=new mysqli($db_servername, $db_username, $db_password, $db_name);
// Check connection
if (mysqli_connect_errno())
{
  echo 'Failed to connect to MySQL:' . mysqli_connect_error();
}
if ($typed_val == ""){
$sql = "SELECT * FROM tbl_contacts;";
}
else {
$sql = "SELECT * FROM tbl_contacts WHERE  $selected_val = '$typed_val'";
}
//echo $sql;
//echo "\n";
$result= $con->query($sql);
if ($result->num_rows > 0) {
  echo "<table><tr><th>Contact Name</th><th>Contact Email</th><th>Contact Address</th><th>Contact Phone</th><th>Favorite Place</th><th>Favorite Place URL</th></tr>";

    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>". $row["contact_name"]. "</td><td>". $row["contact_email"]. "</td><td>" . $row["contact_address"] .  "</td><td>" . $row["contact_phone"] .  "</td><td>" . $row["contact_favoriteplace"] .    "</td><td>" . $row["contact_favoriteplaceurl"] ."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
mysqli_close($con);
}
else {
echo "<h3>Click Filter to search for Contacts</h3>";
}
?>
  </body>
</html>
