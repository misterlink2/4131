<!DOCTYPE html>

<!-- Fig. 19.16: database.php -->
<!-- Querying a database and displaying the results. -->
<html>
   <head>
      <meta charset = "utf-8">
      <title>Search Results</title>
   <style type = "text/css">
         body  { font-family: sans-serif;
                 background-color: lightyellow; } 
         table { background-color: lightblue; 
                 border-collapse: collapse; 
                 border: 1px solid gray; }
         td    { padding: 5px; }
         tr:nth-child(odd) {
                 background-color: white; }
      </style>
   </head>
   <body>
      <?php
         $xml = simplexml_load_file('dbconfig.xml');
         //$db = new SimpleXMLElement($xml->asXML());
         $db_servername = $xml->host; 
         $db_username = $xml->user; 
         $db_password = $xml->password; 
         $db_name = $xml->database; 
/*
         echo $db_servername . "<br>"; 
         echo $db_username . "<br>";
         echo $db_password. "<br>"; 
         echo $db_name . "<br>"; 
         echo $xml->host . "<br>"; 
         echo $xml->user . "<br>"; 
         echo $xml->password . "<br>"; 
         echo $xml->database . "<br>"; 
         echo $xml->port . "<br>"; 
*/
         ini_set('display_errors','1');
         error_reporting(E_ALL);
   
         
         //$select = $_POST["select"]; // creates variable $select

         // build SELECT query
         //$squery = "SELECT " . $select . " FROM books";
         
         //echo $squery;
         
         $conn = new mysqli($db_servername, $db_username , $db_password , 
         $db_name,"3306");
         
         if ($conn->connect_error)
			 echo  die("Could not connect to database </body></html>" );
	    // else 
			//$result = $conn->query($squery);

      ?><!-- end PHP script -->
      
   </body>
</html>

